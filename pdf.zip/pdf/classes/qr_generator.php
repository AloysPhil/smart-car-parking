<?php
include 'phpqrcode/qrlib.php';

$text = "GEEKS FOR GEEKS";

$path = 'images/qrcode/';

$file = $path.uniqid().".png";


// $ecc stores error correction capability('L')
$ecc = 'H';
$pixel_Size = 150;
$frame_Size = 10;

// Generates QR Code and Stores it in directory given
QRcode::png($text, $file, $ecc, $pixel_Size, $frame_Size);

// Displaying the stored QR code from directory
echo "<center><img src='".$file."'></center>";
 
 ?>