<?php
date_default_timezone_set('Africa/Nairobi');

//includes
include 'fpdf/fpdf.php';
include 'fpdf/exfpdf.php';
include 'fpdf/easyTable.php';
include 'phpqrcode/qrlib.php';

$pdf = new exFPDF('L', 'mm', array(
    95,
    200
));
$pdf->AddPage();
$pdf->SetAutoPageBreak(false);
$pdf->SetFillColor(84, 46, 26);
$pdf->Rect(0, 0, $pdf->GetPageWidth() , 20, 'F');
//$pdf->SetDisplayMode(zoom = 25);

$pdf->AddFont('bahaus', '', 'bauhausregular.php');
$pdf->AddFont('coves', '', 'Coves-Bold.php');
$pdf->AddFont('covesl', '', 'Coves-Light.php');
$pdf->AddFont('aquatico', '', 'Aquatico-Regular.php');
$pdf->AddFont('moonb', '', 'Moon-Bold.php');
$pdf->AddFont('moonl', '', 'Moon-Light.php');

$pdf->SetFont('coves', '', 17);
$pdf->setXY(15, 3);
$pdf->setTextColor(255, 255, 255);
$pdf->Cell(19, 12, "Travel Ticket", 0, 0, "R");

$pdf->setXY(26, $pdf->GetY() + 5);
$pdf->SetFont('coves', '', 10);
$pdf->Cell(19, 12, "Present it at the day of travel", 0, 0, "R");

//$pdf->image('images/oyaa5.png', $pdf->GetPageWidth() / 1.7, 2, -140);
//$pdf->setDrawColor(234, 67, 53);
//$pdf->line(1, 20, $pdf->GetPageWidth() - 1, 20);

$pdf->SetFont('bahaus', '', 30);
$pdf->setXY($pdf->GetPageWidth() - 28, 4.5);
$pdf->Cell(19, 12, "Sekondz Tickets", 0, 0, "R");

$pdf->SetFillColor(249, 249, 249);
$pdf->Rect(0, 20, $pdf->GetPageWidth() , $pdf->GetPageHeight() , 'F');

$pdf->SetFont('moonl', '', 12);
$pdf->setTextColor(0, 0, 0);
$y = $pdf->GetY();
$pdf->SetXY(7, $y + 18);
$pdf->MultiCell($pdf->GetPageWidth() - 70, 7, 'KCD 452G' . ' - ' . 'Kangaroo Shuttle', 0, 'L');

// name label
$pdf->SetFont('coves', '', 9);
$pdf->SetTextColor(84, 46, 26);
$pdf->SetXY(12, $y + 25);
$pdf->Cell(10, 7, 'Name:', 0, 'L');

//        name
$pdf->SetFont('bahaus', '', 15);
$pdf->SetTextColor(13, 13, 13);
$pdf->SetY($y + 28);
$pdf->Cell(12, 10, 'aloys otieno', 0, 0, 'L');

// arrival label
$y = $pdf->GetY();
$pdf->SetFont('coves', '', 9);
$pdf->SetTextColor(84, 46, 26);
$pdf->SetXY(12, $y + 10);
$pdf->Cell(10, 7, 'Arrival:', 0, 'L');

//        arrival
$pdf->SetFont('bahaus', '', 15);
$pdf->SetTextColor(13, 13, 13);
$pdf->SetY($y + 13);
$pdf->Cell(12, 10, '04:00:00', 0, 0, 'L');

// departure label
$pdf->SetFont('coves', '', 9);
$pdf->SetTextColor(84, 46, 26);
$pdf->SetXY(50, $y + 10);
$pdf->Cell(10, 7, 'Departure:', 0, 'L');

//        departure
$pdf->SetFont('bahaus', '', 15);
$pdf->SetTextColor(13, 13, 13);
$pdf->SetX(50);
$pdf->SetXY(50, $y + 13);
$pdf->Cell(12, 10, '04:30:00', 0, 0, 'L');

//        row 2
// from label
$y = $pdf->GetY();
$pdf->SetFont('coves', '', 9);
$pdf->SetTextColor(84, 46, 26);
$pdf->SetXY(12, $y + 10);
$pdf->Cell(10, 7, 'From:', 0, 'L');

//        from
$pdf->SetFont('bahaus', '', 15);
$pdf->SetTextColor(13, 13, 13);
$pdf->SetY($y + 13);
$pdf->Cell(12, 10, 'Eldoret', 0, 0, 'L');

// to label
$pdf->SetFont('coves', '', 9);
$pdf->SetTextColor(84, 46, 26);
$pdf->SetXY(50, $y + 10);
$pdf->Cell(10, 7, 'To:', 0, 'L');

//        to
$pdf->SetFont('bahaus', '', 15);
$pdf->SetTextColor(13, 13, 13);
$pdf->SetX(50);
$pdf->SetXY(50, $y + 13);
$pdf->Cell(12, 10, 'Kisumu', 0, 0, 'L');

// ticket no label
$y = $pdf->GetY();
$pdf->SetFont('coves', '', 9);
$pdf->SetTextColor(84, 46, 26);
$pdf->SetXY(12, $y + 10);
$pdf->Cell(10, 7, 'Seat No:', 0, 'L');

//        ticket no
$pdf->SetFont('bahaus', '', 15);
$pdf->SetTextColor(13, 13, 13);
$pdf->SetY($y + 13);
$pdf->Cell(12, 10, '25', 0, 0, 'L');

// date label
$pdf->SetFont('coves', '', 9);
$pdf->SetTextColor(84, 46, 26);
$pdf->SetXY(50, $y + 10);
$pdf->Cell(10, 7, 'Travel Date:', 0, 'L');

//        date
$pdf->SetFont('bahaus', '', 15);
$pdf->SetTextColor(13, 13, 13);
$pdf->SetX(50);
$pdf->SetXY(50, $y + 13);
$pdf->Cell(12, 10, '09-03-2026', 0, 0, 'L');

// // footer
$pdf->setXY($pdf->GetPageWidth() - 40, $pdf->GetPageHeight() - 20);
$pdf->setTextColor(84, 46, 26);
$pdf->SetFont('bahaus', '', 17);
$pdf->Cell(10, 5, 'Ticket #' . '11', 0, "L");

$pdf->setXY($pdf->GetPageWidth() - 30, $pdf->GetPageHeight() - 5);
$pdf->setTextColor(77, 77, 77);
$pdf->SetFont('bahaus', '', 9);
$pdf->Cell(10, 5, '2019-12-12 18:08:30', 0, "L");

//generate qr here
$text = "GEEKS FOR GEEKS";

$path = 'images/qrcode/';
$filename = uniqid();

$file = $path . $filename . ".png";

// $ecc stores error correction capability('L')
$ecc = 'H';
$pixel_Size = 4;
$frame_Size = 4;

// Generates QR Code and Stores it in directory given
QRcode::png($text, $file, $ecc, $pixel_Size, $frame_Size);

$pdf->image('images/qrcode/' . $filename . '.png', $pdf->GetPageWidth() - 50, 25, -76);

//$this->pdf->image( 'temp/'.$ticketDetails['fullname'].$ticketDetails['id'].'.png',$this->pdf->GetPageWidth()-50,25,-76);
$pdf->Output();

