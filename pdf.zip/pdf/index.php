<?php
require "../assets/fpdf186/fpdf.php";
include "../database/connection.php";

$order_id = $_GET["order_id"];

class PDF extends FPDF
{
    // Page header
    function Header()
    {
        // Logo
        $this->Image("../assets/images/logo/logo-white.png", 10, 6, 30);
        // Arial bold 15
        $this->SetFont("Sour Gummy", "B", 12);
        // Move to the right
        $this->Cell(80);
        // Title
        $this->Cell(30, 10, "Title", 1, 0, "C");
        // Line break
        $this->Ln(20);
    }

    // Page footer
    function Footer()
    {
        // Position at 1.5 cm from bottom
        $this->SetY(-15);
        // Arial italic 8
        $this->SetFont("Sour Gummy", "", 8);
        // Page number
        $this->Cell(0, 10, "Page " . $this->PageNo() . "/{nb}", 0, 0, "C");
    }

    // Load data
    function LoadData($file)
    {
        // Read file lines
        $lines = file($file);
        $data = [];
        foreach ($lines as $line) {
            $data[] = explode(";", trim($line));
        }
        return $data;
    }

    // Simple table
    function BasicTable($header, $data)
    {
        // Header
        foreach ($header as $col) {
            $this->Cell(40, 7, $col, 1);
        }
        $this->Ln();
        // Data
        foreach ($data as $row) {
            foreach ($row as $col) {
                $this->Cell(40, 6, $col, 1);
                $this->SetFont("Sour Gummy", "", 12);
            }
            $this->Ln();
        }
    }
}

// Set the INSERT SQL data
$sql = "SELECT Name, Quantity, price FROM Items WHERE OrderID = '$order_id'";

// Process the query so that we will save the date of birth
$results = $conn->query($sql);

// Fetch Associative array
$data = $results->fetch_all(MYSQLI_ASSOC);

// Instanciation of inherited class
$pdf = new PDF();

// Column headings
$header = ["Name", "Quantity", "Price @"];

// Data loading
//$data = $pdf->LoadData("../assets/fpdf186/tutorial/countries.txt");

$pdf->AddFont("Sour Gummy", "", "SourGummy-Regular.php");
$pdf->AddFont("Sour Gummy", "B", "SourGummy-Bold.php");
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->BasicTable($header, $data);
$pdf->SetFont("Sour Gummy", "", 12);
$pdf->Output();

// Free result set
$results->free_result();

// Close the connection after using it
$conn->close();

?>
